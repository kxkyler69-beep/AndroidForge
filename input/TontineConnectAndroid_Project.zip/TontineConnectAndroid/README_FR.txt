TONTINECONNECT — PROJET ANDROID

Ce dossier contient un projet Android Studio qui encapsule la version web de TontineConnect dans une application Android (WebView).

POUR GENERER L'APK :
1. Installer Android Studio sur un ordinateur.
2. Ouvrir Android Studio puis choisir "Open".
3. Sélectionner le dossier TontineConnectAndroid décompressé.
4. Attendre la synchronisation Gradle.
5. Ouvrir Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio génère l'APK debug dans :
   app/build/outputs/apk/debug/app-debug.apk

LIMITES IMPORTANTES :
- Ceci est un prototype local de démonstration.
- Les données sont conservées dans le stockage du navigateur de l'application sur cet appareil.
- Il n'y a pas encore de comptes sécurisés, de serveur, de synchronisation entre téléphones ni de paiement TMoney/Flooz.
- Le bouton "Marquer comme payée" est uniquement un statut manuel : il ne déclenche aucun transfert d'argent.
- Avant toute utilisation avec de l'argent réel, il faudra développer un backend sécurisé, une authentification, des contrôles d'accès, des sauvegardes et intégrer un prestataire de paiement agréé.
